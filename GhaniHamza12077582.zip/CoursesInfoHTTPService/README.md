CoursesInfoHTTPService
=======================

This is a generated application from the Mavan appengine-skeleton archetype. To demonstrate Http Service with XML, Json and String. 
